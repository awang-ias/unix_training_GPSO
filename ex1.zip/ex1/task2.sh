#!/bin/bash

adsafeurl="Sitelist.txt"
advid="11922"

input="apnappservers.txt"
cr=$'\r'

while read sites || [ -n "$sites" ]
do
    sites="${sites%$cr}"
    echo ${sites} >> task2.txt
    echo ${sites}
    while read line || [ -n "$line" ]
    do
        counter=0
        line="${line%$cr}"
        echo "${line}" >> task2.txt
        echo "${line}"
        for i in {1..50}; do
            present=$(curl -v 'http://'"${line}"'/db2/client/'"${advid}"'/seg.an?adsafe_url=http://www.'"${sites}" -v 2>&1 | grep -E "1507653")
            if [[ "${present}" == *1507653* ]]
            then
                counter=$((counter+1)) 
                echo "${counter}"
            fi
        done
        echo 'No. of times segment 1507653 returned: '"${counter}" >> task2.txt
    done< "$input"
done <"$adsafeurl"